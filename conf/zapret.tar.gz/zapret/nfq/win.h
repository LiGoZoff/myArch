#pragma once

#ifdef __CYGWIN__

#include <stdbool.h>

bool service_run();

#endif

