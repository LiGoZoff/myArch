Copy "mdig" folder here !
