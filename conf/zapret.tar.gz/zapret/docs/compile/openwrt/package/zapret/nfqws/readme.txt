Copy "nfq" folder here !
